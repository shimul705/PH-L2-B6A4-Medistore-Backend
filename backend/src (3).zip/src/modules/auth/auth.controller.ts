import type { Request, Response } from "express";
import { fromNodeHeaders } from "better-auth/node";
import { auth } from "../../lib/auth";
import { asyncHandler } from "../../middlewares/asyncHandler";
import { prisma } from "../../lib/prisma";
import { ApiError } from "../../utils/ApiError";

const pipeAuthResponse = async (response: Response, res: Response) => {
  // Forward status
  res.status(response.status);

  // Forward regular headers except Set-Cookie (needs special handling)
  response.headers.forEach((v, k) => {
    if (k.toLowerCase() === "set-cookie") return;
    res.setHeader(k, v);
  });

  // Preserve Set-Cookie headers (Node fetch keeps these separate)
  const getSetCookie = (response.headers as any).getSetCookie as undefined | (() => string[]);
  const cookies = typeof getSetCookie === "function" ? getSetCookie() : [];

  if (cookies.length > 0) {
    // Express supports an array for multiple Set-Cookie headers
    res.setHeader("Set-Cookie", cookies);
  } else {
    // Fallback: some runtimes expose a single combined header
    const sc = response.headers.get("set-cookie");
    if (sc) res.setHeader("Set-Cookie", sc);
  }

  // If this is a redirect, end the response via redirect so browsers follow it.
  const location = response.headers.get("location");
  if (location && response.status >= 300 && response.status < 400) {
    return res.redirect(response.status, location);
  }

  // Otherwise, pipe JSON body if present
  const text = await response.text();
  return res.send(text ? JSON.parse(text) : null);
};


export const AuthController = {
  register: asyncHandler(async (req: Request, res: Response) => {
    const { name, email, password, role } = req.body;

    const response = await auth.api.signUpEmail({
      body: {
        // `role` is required by our Better Auth additionalFields config.
        // Validation should ensure it exists and is one of the allowed roles.
        name,
        email,
        password,
        role,
      },
      // Return a Response so cookies/headers (if any) are preserved
      asResponse: true,
    });

    return pipeAuthResponse(response, res);
  }),

  login: asyncHandler(async (req: Request, res: Response) => {
    const { email, password } = req.body;

    const u = await prisma.user.findUnique({ where: { email } });
    if (u?.isBanned) throw new ApiError(403, "Your account is banned");

    // Prevent banned users from creating a new session
    const user = await prisma.user.findUnique({ where: { email } });
    if (user?.isBanned) throw new ApiError(403, "Your account is banned");

    const response = await auth.api.signInEmail({
      body: { email, password },
      asResponse: true,
    });

    return pipeAuthResponse(response, res);
  }),

  logout: asyncHandler(async (req: Request, res: Response) => {
    // End the current session (if any) and clear cookies
    const response = await auth.api.signOut({
      headers: fromNodeHeaders(req.headers),
      asResponse: true,
    } as any);

    return pipeAuthResponse(response, res);
  }),


  google: asyncHandler(async (req: Request, res: Response) => {
    // Starts Google OAuth flow.
    // If callbackURL isn't provided, Better Auth may fallback to the backend baseURL
    // which would send the user to http://localhost:4000 after consent.
    // We support callbackURL as a query param so the frontend can control where the
    // user lands after OAuth.
    const callbackURL = typeof req.query.callbackURL === "string" ? req.query.callbackURL : undefined;

    const response = await auth.api.signInSocial({
      body: {
        provider: "google",
        ...(callbackURL ? { callbackURL } : {}),
      },
      asResponse: true,
    } as any);

    return pipeAuthResponse(response, res);
  }),

  me: asyncHandler(async (req: Request, res: Response) => {
    const session = await auth.api.getSession({
      headers: fromNodeHeaders(req.headers),
    });
    res.json({ success: true, data: session });
  }),
};
