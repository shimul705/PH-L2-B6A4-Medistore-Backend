import { Request, Response } from "express";
import prisma from "../../utils/prisma";

export const getHomepageReviews = async (req: Request, res: Response) => {
  try {
    const limit = Number(req.query.limit) || 6;

    const reviews = await prisma.review.findMany({
      take: limit,
      orderBy: { createdAt: "desc" },
      include: {
        customer: {
          select: { name: true }
        },
        order: {
          include: {
            items: {
              include: {
                medicine: {
                  select: { name: true }
                }
              }
            }
          }
        }
      }
    });

    res.json(reviews);
  } catch (error) {
    res.status(500).json({ message: "Failed to fetch reviews" });
  }
};

export const getOrderReview = async (req: Request, res: Response) => {
  try {
    const { orderId } = req.params;

    const review = await prisma.review.findUnique({
      where: { orderId }
    });

    res.json(review);
  } catch (error) {
    res.status(500).json({ message: "Failed to fetch review" });
  }
};

export const submitOrderReview = async (req: Request, res: Response) => {
  try {
    const { orderId } = req.params;
    const { text } = req.body;
    const userId = (req as any).user?.id;

    if (!text || text.trim() === "") {
      return res.status(400).json({ message: "Review text is required" });
    }

    const order = await prisma.order.findUnique({
      where: { id: orderId }
    });

    if (!order) {
      return res.status(404).json({ message: "Order not found" });
    }

    if (
      order.status !== "DELIVERED" &&
      order.status !== "CANCELLED"
    ) {
      return res.status(400).json({
        message:
          "You can only review delivered or cancelled orders."
      });
    }

    const existing = await prisma.review.findUnique({
      where: { orderId }
    });

    if (existing) {
      return res.status(400).json({
        message: "Review already submitted."
      });
    }

    const prefix =
      order.status === "DELIVERED"
        ? "I Received My order, "
        : "My Order is canceled, ";

    const review = await prisma.review.create({
      data: {
        orderId,
        customerId: userId,
        comment: prefix + text
      }
    });

    res.status(201).json(review);
  } catch (error) {
    res.status(500).json({ message: "Failed to submit review" });
  }
};
