import { Router } from "express";
import { requireAuth, requireRole } from "../../middlewares/authGuard";
import { OrderReviewController } from "./orderReview.controller";

const router = Router();

router.get("/", OrderReviewController.list);

router.use(requireAuth, requireRole("CUSTOMER"));
router.get("/order/:orderId", OrderReviewController.myForOrder);
router.post("/order/:orderId", OrderReviewController.create);

export default router;
