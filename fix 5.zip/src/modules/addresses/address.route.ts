import { Router } from "express";
import { requireAuth, requireRole } from "../../middlewares/authGuard";
import { AddressController } from "./address.controller";

const router = Router();

router.use(requireAuth, requireRole("CUSTOMER"));

router.get("/", AddressController.list);
router.get("/default", AddressController.default);
router.post("/", AddressController.create);
router.patch("/:id", AddressController.update);
router.delete("/:id", AddressController.delete);
router.post("/:id/default", AddressController.setDefault);

export default router;
