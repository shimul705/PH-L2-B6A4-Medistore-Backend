import { prisma } from "../../lib/prisma";
import { ApiError } from "../../utils/ApiError";

export type AddressPayload = {
  type?: string;
  name: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  zip: string;
};

export async function listAddresses(userId: string) {
  return prisma.address.findMany({ where: { userId }, orderBy: { createdAt: "desc" } });
}

export async function getDefaultAddress(userId: string) {
  return prisma.address.findFirst({ where: { userId, isDefault: true } });
}

export async function createAddress(userId: string, payload: AddressPayload) {
  const existing = await prisma.address.count({ where: { userId } });
  const shouldDefault = existing === 0;
  return prisma.address.create({
    data: {
      userId,
      type: payload.type || "Home",
      name: payload.name,
      phone: payload.phone,
      address: payload.address,
      city: payload.city,
      state: payload.state,
      zip: payload.zip,
      isDefault: shouldDefault,
    },
  });
}

export async function updateAddress(userId: string, id: string, payload: AddressPayload) {
  const found = await prisma.address.findFirst({ where: { id, userId } });
  if (!found) throw new ApiError(404, "Address not found");

  return prisma.address.update({
    where: { id },
    data: {
      type: payload.type ?? found.type,
      name: payload.name ?? found.name,
      phone: payload.phone ?? found.phone,
      address: payload.address ?? found.address,
      city: payload.city ?? found.city,
      state: payload.state ?? found.state,
      zip: payload.zip ?? found.zip,
    },
  });
}

export async function deleteAddress(userId: string, id: string) {
  const found = await prisma.address.findFirst({ where: { id, userId } });
  if (!found) throw new ApiError(404, "Address not found");

  await prisma.address.delete({ where: { id } });

  // ensure there is a default address if any remain
  const remaining = await prisma.address.findMany({ where: { userId }, orderBy: { createdAt: "desc" } });
  if (remaining.length > 0 && !remaining.some((a) => a.isDefault)) {
    await prisma.address.update({ where: { id: remaining[0].id }, data: { isDefault: true } });
  }
}

export async function setDefaultAddress(userId: string, id: string) {
  const found = await prisma.address.findFirst({ where: { id, userId } });
  if (!found) throw new ApiError(404, "Address not found");

  return prisma.$transaction(async (tx) => {
    await tx.address.updateMany({ where: { userId }, data: { isDefault: false } });
    return tx.address.update({ where: { id }, data: { isDefault: true } });
  });
}
