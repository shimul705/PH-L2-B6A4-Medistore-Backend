import type { Request, Response } from "express";
import { asyncHandler } from "../../middlewares/asyncHandler";
import { ApiResponse } from "../../utils/ApiResponse";
import { createAddress, deleteAddress, getDefaultAddress, listAddresses, setDefaultAddress, updateAddress } from "./address.service";

export const AddressController = {
  list: asyncHandler(async (req: Request, res: Response) => {
    const data = await listAddresses(req.user!.id);
    res.json(new ApiResponse(true, "Addresses fetched", data));
  }),
  default: asyncHandler(async (req: Request, res: Response) => {
    const data = await getDefaultAddress(req.user!.id);
    res.json(new ApiResponse(true, "Default address", data));
  }),
  create: asyncHandler(async (req: Request, res: Response) => {
    const data = await createAddress(req.user!.id, req.body);
    res.status(201).json(new ApiResponse(true, "Address created", data));
  }),
  update: asyncHandler(async (req: Request, res: Response) => {
    const data = await updateAddress(req.user!.id, req.params.id, req.body);
    res.json(new ApiResponse(true, "Address updated", data));
  }),
  delete: asyncHandler(async (req: Request, res: Response) => {
    await deleteAddress(req.user!.id, req.params.id);
    res.json(new ApiResponse(true, "Address deleted"));
  }),
  setDefault: asyncHandler(async (req: Request, res: Response) => {
    const data = await setDefaultAddress(req.user!.id, req.params.id);
    res.json(new ApiResponse(true, "Default address updated", data));
  }),
};
