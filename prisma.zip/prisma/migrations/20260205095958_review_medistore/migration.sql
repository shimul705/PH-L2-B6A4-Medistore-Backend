/*
  Warnings:

  - You are about to drop the `Address` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `OrderReview` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropForeignKey
ALTER TABLE "Address" DROP CONSTRAINT "Address_userId_fkey";

-- DropForeignKey
ALTER TABLE "OrderReview" DROP CONSTRAINT "OrderReview_customerId_fkey";

-- DropForeignKey
ALTER TABLE "OrderReview" DROP CONSTRAINT "OrderReview_orderId_fkey";

-- DropTable
DROP TABLE "Address";

-- DropTable
DROP TABLE "OrderReview";
